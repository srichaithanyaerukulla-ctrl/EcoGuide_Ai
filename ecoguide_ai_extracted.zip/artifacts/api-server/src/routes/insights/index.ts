import { Router } from "express";
import { GenerateInsightsBody, ChatInsightsBody } from "@workspace/api-zod";

const router = Router();

const GEMINI_MODELS = [
  "gemini-1.5-flash",
  "gemini-2.0-flash",
  "gemini-1.5-flash-8b",
];

async function callGemini(prompt: string, apiKey: string): Promise<string> {
  let lastError: Error = new Error("No models available");

  for (const model of GEMINI_MODELS) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 1024, topP: 0.9 },
      }),
    });

    if (response.status === 429) {
      lastError = new Error(`Gemini rate limit on model ${model}`);
      continue;
    }

    if (!response.ok) {
      throw new Error(`Gemini API error: ${response.status}`);
    }

    const data = (await response.json()) as {
      candidates?: Array<{
        content?: { parts?: Array<{ text?: string }> };
        finishReason?: string;
      }>;
    };

    const candidate = data.candidates?.[0];
    if (!candidate || candidate.finishReason === "SAFETY") {
      throw new Error("Gemini returned no usable content");
    }

    return candidate.content?.parts?.[0]?.text ?? "";
  }

  throw lastError;
}

function buildAnalysisPrompt(d: {
  total: number; transport: number; home: number; food: number; stuff: number;
  carKm: number; isEV: boolean; shortFlights: number; longFlights: number;
  elecKwh: number; renewPct: number; dietType: string; foodWaste: string; clothingItems: number;
}): string {
  const renewPctDisplay = d.renewPct <= 1 ? Math.round(d.renewPct * 100) : Math.round(d.renewPct);
  return `You are EcoGuide AI, a friendly carbon footprint advisor.

User's annual carbon footprint:
- Total: ${d.total}t CO₂e/year
- Transport: ${d.transport}t (car: ${d.carKm}km/wk, EV: ${d.isEV}, short flights: ${d.shortFlights}/yr, long flights: ${d.longFlights}/yr)
- Home: ${d.home}t (electricity: ${d.elecKwh}kWh/mo, renewables: ${renewPctDisplay}%)
- Food: ${d.food}t (diet: ${d.dietType}, waste: ${d.foodWaste})
- Stuff: ${d.stuff}t (clothing: ${d.clothingItems} items/mo)

Global average: 4.8t | 2050 target: 2t

Write a personalised analysis with exactly these five sections:

### 🔍 Your Footprint at a Glance
2-3 sentences comparing to global benchmarks. Name their biggest emission category and exact tonnage.

### 🎯 Your Top 3 Priority Actions
The 3 highest-impact actions specific to this person's numbers. For each: bold the action name, explain why it matters for their data, state estimated CO₂ saving in kg/year.

### 💡 Quick Wins This Week
Exactly 3 bullet points. One sentence each. Minimal effort, real impact.

### 🌱 12-Month Roadmap
Month pairs (Months 1-2, 3-4, etc.) for a 30% reduction. One sentence per pair.

### 📊 Collective Impact
One sentence: if 1 million people took their single highest-impact action, total CO₂ saved (show the maths).

Tone: warm, specific, data-driven, encouraging — never preachy. Reference their actual numbers throughout.`;
}

function buildFallback(d: { total: number; transport: number; home: number; food: number; stuff: number }): string {
  const cats = { Transport: d.transport, Home: d.home, Food: d.food, Stuff: d.stuff };
  const biggest = Object.entries(cats).sort((a, b) => b[1] - a[1])[0];
  const saving = Math.round(biggest[1] * 200);
  return `### 🔍 Your Footprint at a Glance
Your total footprint is ${d.total}t CO₂e/year — ${d.total > 4.8 ? `${((d.total / 4.8 - 1) * 100).toFixed(0)}% above` : `${((1 - d.total / 4.8) * 100).toFixed(0)}% below`} the global average of 4.8t. Your biggest category is ${biggest[0]} at ${biggest[1].toFixed(2)}t. To reach the 2050 target of 2t, you'd need to cut ${(d.total - 2).toFixed(1)}t more.

### 🎯 Your Top 3 Priority Actions
**Reduce ${biggest[0].toLowerCase()} emissions** — this is your largest category. Targeting it first gives the biggest return on effort. Potential saving: ${saving} kg/year.
**Switch to renewable energy** — if you're not already on 100% renewables, this single change can cut your home emissions significantly. Potential saving: ${Math.round(d.home * 300)} kg/year.
**Cut long-haul flights** — each long-haul return trip adds ~1.6t. Even one fewer flight per year makes a meaningful dent. Potential saving: 1620 kg/year.

### 💡 Quick Wins This Week
- Set your thermostat 1°C lower — a tiny change that saves ~450 kg CO₂e per year.
- Switch to a plant-based meal twice this week — easy, cheap, and saves ~200 kg/year if maintained.
- Unplug devices on standby — idle electronics silently drain energy; a power strip makes this effortless.

### 🌱 12-Month Roadmap
**Months 1-2:** Audit your home energy use and switch to a green energy tariff if available.
**Months 3-4:** Commit to two meat-free days per week and track the habit.
**Months 5-6:** Review your transport habits — consider cycling or public transit for short trips.
**Months 7-8:** Reduce online shopping frequency and buy second-hand where possible.
**Months 9-10:** Insulate your home or draught-proof windows and doors.
**Months 11-12:** Review your year, celebrate progress, and set a new 30% reduction target.

### 📊 Collective Impact
If 1 million people took your highest-impact action and saved ~${saving} kg each, that's ${(saving * 1_000_000 / 1_000_000).toFixed(0)} million kg — or ${(saving * 1_000_000 / 1_000_000_000).toFixed(2)} million tonnes — of CO₂ removed every year.`;
}

// POST /insights/generate
router.post("/insights/generate", async (req, res) => {
  const parse = GenerateInsightsBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    req.log.error("GEMINI_API_KEY not set");
    res.status(500).json({ error: "AI service not configured" });
    return;
  }

  const d = parse.data;
  try {
    const text = await callGemini(buildAnalysisPrompt(d), apiKey);
    res.json({ text, generatedAt: new Date().toISOString() });
  } catch (err) {
    req.log.warn({ err }, "Gemini unavailable — serving fallback analysis");
    res.json({ text: buildFallback(d), generatedAt: new Date().toISOString() });
  }
});

// POST /insights/chat
router.post("/insights/chat", async (req, res) => {
  const parse = ChatInsightsBody.safeParse(req.body);
  if (!parse.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "AI service not configured" });
    return;
  }

  const { footprint: fp, messages } = parse.data;
  const renewPctDisplay = fp.renewPct <= 1 ? Math.round(fp.renewPct * 100) : Math.round(fp.renewPct);

  const context = `You are EcoGuide AI, a friendly and knowledgeable carbon footprint advisor. You are having a conversation with a user about their personal carbon footprint.

User's footprint data for context:
- Total: ${fp.total}t CO₂e/year (global avg: 4.8t, 2050 target: 2t)
- Transport: ${fp.transport}t | Home: ${fp.home}t | Food: ${fp.food}t | Stuff: ${fp.stuff}t
- Car: ${fp.carKm}km/wk (EV: ${fp.isEV}), flights: ${fp.shortFlights} short + ${fp.longFlights} long/yr
- Electricity: ${fp.elecKwh}kWh/mo, renewables: ${renewPctDisplay}%, diet: ${fp.dietType}, food waste: ${fp.foodWaste}

Answer questions specifically about their footprint. Be concise (2-5 sentences unless detail is requested), warm, and data-driven. Never be preachy.

Conversation so far:
${messages
  .slice(0, -1)
  .map((m) => `${m.role === "user" ? "User" : "EcoGuide AI"}: ${m.content}`)
  .join("\n")}

User's latest message: ${messages[messages.length - 1]?.content ?? ""}

Respond as EcoGuide AI:`;

  try {
    const text = await callGemini(context, apiKey);
    res.json({ text, generatedAt: new Date().toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to generate chat reply");
    res.status(500).json({ error: "Failed to generate response. Please try again." });
  }
});

export default router;
