import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="font-sans selection:bg-[var(--sage)] selection:text-white">
      <HeroSection />
      <HowItWorksSection />
      <CategoriesSection />
      <GlobalContextSection />
      <CtaSection />
    </div>
  );
}

function HeroSection() {
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = 4.8;
    const duration = 2200;
    const startTime = performance.now();

    const animate = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      setCounter(end * easeProgress);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, []);

  return (
    <section className="pt-32 pb-20 md:pt-48 md:pb-32 bg-gradient-to-b from-[var(--forest)] to-[var(--moss)] text-white overflow-hidden relative">
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-7xl font-serif leading-tight mb-6">
            The average person emits <span className="text-[var(--amber)] font-mono">{counter.toFixed(1)}</span> tonnes CO₂ / year
          </h1>
          <p className="text-xl md:text-2xl text-[var(--mist)] mb-10 max-w-2xl font-light">
            Your footprint is personal. EcoGuide AI helps you measure it, understand it, and actually do something about it.
          </p>
          <div className="flex flex-wrap gap-4 mb-16">
            <Link href="/track" className="inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-[var(--fern)] hover:bg-[#3d754c] text-white text-lg h-14 px-8 shadow-sm">
              Calculate Mine →
            </Link>
            <Link href="/understand" className="inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-white/30 text-white hover:bg-white/10 text-lg h-14 px-8">
              Learn the Basics
            </Link>
          </div>
          
          <div className="flex gap-8 text-sm font-mono text-[var(--mist)]">
            <div><strong className="text-white text-xl">4.8t</strong><br/>Global Avg</div>
            <div><strong className="text-white text-xl">16t</strong><br/>US Avg</div>
            <div><strong className="text-[var(--sage)] text-xl">2t</strong><br/>2050 Target</div>
          </div>
        </div>
      </div>
      
      <div className="hidden lg:block absolute top-1/2 right-[10%] transform -translate-y-1/2">
        <div className="relative w-[300px] h-[300px] animate-float">
          <div className="absolute inset-0 text-[180px] flex items-center justify-center select-none" aria-hidden="true">🌍</div>
          <div className="absolute inset-0 flex items-center justify-center animate-orbit-fast select-none">
            <div className="text-3xl">🚗</div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center animate-orbit-fast select-none" style={{animationDelay: '-10s'}}>
            <div className="text-3xl">🏠</div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center animate-orbit-slow select-none">
            <div className="text-3xl">🍽️</div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center animate-orbit-slow select-none" style={{animationDelay: '-16s'}}>
            <div className="text-3xl">✈️</div>
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorksSection() {
  const steps = [
    { id: 1, icon: "🔍", title: "Understand", desc: "Learn what makes up your carbon footprint and why each category matters." },
    { id: 2, icon: "📊", title: "Track", desc: "Enter your real-world habits. Get your personal CO₂e total in tonnes per year." },
    { id: 3, icon: "🌱", title: "Reduce", desc: "Get AI-powered actions ranked by YOUR biggest impact opportunities." },
  ];

  return (
    <section className="py-24 bg-[var(--paper)]">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-serif text-center text-[var(--forest)] mb-16">Three steps to a lighter footprint</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map(s => (
            <Card key={s.id} className="border-[var(--linen)] bg-[var(--paper)] hover:-translate-y-1 hover:shadow-md transition-all duration-300">
              <CardContent className="p-8 relative">
                <div className="absolute top-4 right-4 bg-[var(--mist)] text-[var(--forest)] font-mono text-sm font-bold w-6 h-6 flex items-center justify-center rounded-full">{s.id}</div>
                <div className="text-4xl mb-4">{s.icon}</div>
                <h3 className="text-2xl font-serif text-[var(--forest)] mb-3">{s.title}</h3>
                <p className="text-[var(--pewter)] text-base">{s.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function CategoriesSection() {
  const cards = [
    { icon: "🚗", title: "Transport", pct: 29, color: "var(--fern)", desc: "Flights, daily drives, and public transit." },
    { icon: "🏠", title: "Home Energy", pct: 21, color: "var(--amber)", desc: "Electricity, heating, and how you power your home." },
    { icon: "🍽️", title: "Food & Diet", pct: 26, color: "var(--moss)", desc: "What you eat is one of the biggest levers you have." },
    { icon: "🛍️", title: "Stuff & Shopping", pct: 24, color: "var(--slate)", desc: "The hidden footprint in every purchase." },
  ];

  return (
    <section className="py-24 bg-[var(--cream)]">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-serif text-center text-[var(--forest)] mb-16">Four areas that define your footprint</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {cards.map((c, i) => (
            <Link key={i} href="/understand" className="block outline-none">
              <Card className="border-[var(--linen)] bg-[var(--paper)] hover:-translate-y-1 hover:shadow-md transition-all duration-300 h-full">
                <CardContent className="p-6">
                  <div className="text-3xl mb-4" aria-hidden="true">{c.icon}</div>
                  <h3 className="text-xl font-serif text-[var(--forest)] mb-2">{c.title} — {c.pct}% of global emissions</h3>
                  <p className="text-[var(--pewter)] text-sm mb-4">{c.desc}</p>
                  <div className="h-2 w-full bg-[var(--linen)] rounded-full overflow-hidden" role="progressbar" aria-valuenow={c.pct} aria-valuemin={0} aria-valuemax={100}>
                    <div className="h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${c.pct}%`, backgroundColor: c.color }}></div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

function GlobalContextSection() {
  const data = [
    { country: "India", flag: "🇮🇳", val: 1.9 },
    { country: "World", flag: "🌍", val: 4.8 },
    { country: "UK", flag: "🇬🇧", val: 5.5 },
    { country: "EU", flag: "🇪🇺", val: 6.8 },
    { country: "Australia", flag: "🇦🇺", val: 15.4 },
    { country: "USA", flag: "🇺🇸", val: 16.0 },
  ];

  const maxVal = 16.0;

  return (
    <section className="py-24 bg-[var(--forest)] text-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <h2 className="text-4xl font-serif mb-4">How does YOUR country compare?</h2>
          <p className="text-lg text-[var(--mist)]">The global average needs to fall 60% by 2050 to stay within 1.5°C of warming.</p>
        </div>

        <div className="max-w-4xl mx-auto relative pt-12 pb-8 px-4 border-b border-[var(--moss)]">
          {/* Target line */}
          <div className="absolute left-0 right-0 border-t-2 border-dashed border-[var(--sage)] z-10 flex items-center" style={{ bottom: `${(2.0 / maxVal) * 100}%` }}>
            <span className="bg-[var(--forest)] text-[var(--sage)] font-mono text-sm px-2 -translate-y-1/2 ml-2">2.0t Target</span>
          </div>
          
          <div className="flex items-end justify-between h-[300px] relative z-20">
            {data.map((d, i) => (
              <div key={i} className="flex flex-col items-center w-1/6 px-1">
                <div className="font-mono text-sm mb-2 opacity-80">{d.val}t</div>
                <div 
                  className={`w-full max-w-[60px] rounded-t-sm transition-all duration-1000 ${d.val <= 2 ? 'bg-[var(--sage)]' : d.val < 8 ? 'bg-[var(--moss)]' : 'bg-[var(--amber)]'}`} 
                  style={{ height: `${(d.val / maxVal) * 100}%` }}
                ></div>
                <div className="mt-3 text-center">
                  <div className="text-2xl mb-1">{d.flag}</div>
                  <div className="text-xs md:text-sm text-[var(--mist)]">{d.country}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function CtaSection() {
  return (
    <section className="py-24 bg-[var(--cream)]">
      <div className="container mx-auto px-6 text-center max-w-2xl">
        <h2 className="text-4xl md:text-5xl font-serif text-[var(--forest)] mb-6">Ready to know your number?</h2>
        <p className="text-xl text-[var(--pewter)] mb-10">It takes 3 minutes. No sign-up. Just honest data.</p>
        <Link href="/track" className="inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-[var(--fern)] hover:bg-[#3d754c] text-white text-xl h-16 px-10 shadow-md">
          Calculate My Footprint →
        </Link>
      </div>
    </section>
  );
}
