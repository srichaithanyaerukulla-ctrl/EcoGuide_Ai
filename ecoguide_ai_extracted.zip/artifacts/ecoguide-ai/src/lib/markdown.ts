export function renderMarkdown(markdown: string): string {
  if (!markdown) return '';
  
  let html = markdown
    // Sanitize basic tags
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // Headings
    .replace(/^### (.*$)/gim, '<h3 class="text-xl font-serif mt-6 mb-3">$1</h3>')
    .replace(/^## (.*$)/gim, '<h2 class="text-2xl font-serif mt-8 mb-4">$1</h2>')
    .replace(/^# (.*$)/gim, '<h1 class="text-3xl font-serif mt-8 mb-4">$1</h1>')
    // Bold
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Lists
    .replace(/^- (.*$)/gim, '<li class="ml-4 list-disc mb-1">$1</li>')
    // Paragraphs
    .replace(/^\s*(\n)?([^<].*)/gim, function(match, p1, p2) {
      if (/^<h|^<li/.test(p2)) return match;
      return '<p class="mb-4 text-[var(--mist)]">' + p2 + '</p>';
    });

  // Wrap consecutive li elements in ul
  html = html.replace(/(<li.*?>.*<\/li>(\s*<li.*?>.*<\/li>)*)/gim, '<ul class="mb-4">$1</ul>');

  return html;
}
