/**
 * calculator.test.js
 * Unit tests for the carbon footprint calculation engine.
 * Run with: npm test
 */
import { describe, it, expect } from 'vitest';
import { calculateFootprint, getScoreLabel } from './calculator.js';

// ── Helpers ────────────────────────────────────────────────────────────────
/** Minimal valid input (all zeroes except required selects) */
const base = {
  carKm: 0, isEV: false, transitHrs: 0, shortFlights: 0, longFlights: 0,
  elecKwh: 0, gasM3: 0, renewShare: 0, hhSize: 1,
  dietType: 'meat', foodWaste: 'medium', localFood: 'medium',
  clothingItems: 0, electronics: 0, onlineOrders: 0,
};

// ── calculateFootprint ─────────────────────────────────────────────────────
describe('calculateFootprint — transport', () => {
  it('returns zero transport when no vehicle inputs given', () => {
    const r = calculateFootprint(base);
    expect(r.transport).toBe(0);
  });

  it('EV emits ~4x less than petrol for same weekly km', () => {
    const petrol = calculateFootprint({ ...base, carKm: 200, isEV: false });
    const ev     = calculateFootprint({ ...base, carKm: 200, isEV: true  });
    expect(ev.transport).toBeLessThan(petrol.transport);
    expect(petrol.transport / ev.transport).toBeCloseTo(200 * 52 * 0.21 / (200 * 52 * 0.053), 0);
  });

  it('each long-haul flight adds 1.62 tonnes', () => {
    const r1 = calculateFootprint({ ...base, longFlights: 1 });
    const r2 = calculateFootprint({ ...base, longFlights: 2 });
    expect(r1.transport).toBeCloseTo(1.620, 2);
    expect(r2.transport).toBeCloseTo(3.240, 2);
  });

  it('each short-haul flight adds 0.255 tonnes', () => {
    const r = calculateFootprint({ ...base, shortFlights: 4 });
    expect(r.transport).toBeCloseTo(1.020, 2);
  });

  it('public transit hours contribute to transport', () => {
    const r = calculateFootprint({ ...base, transitHrs: 10 });
    expect(r.transport).toBeGreaterThan(0);
    expect(r.transport).toBeCloseTo(10 * 52 * 0.089 / 1000, 4);
  });
});

describe('calculateFootprint — home energy', () => {
  it('renewables reduce electricity emissions proportionally', () => {
    const none = calculateFootprint({ ...base, elecKwh: 300, renewShare: 0   });
    const half = calculateFootprint({ ...base, elecKwh: 300, renewShare: 0.5 });
    const full = calculateFootprint({ ...base, elecKwh: 300, renewShare: 1   });
    expect(half.home).toBeCloseTo(none.home / 2, 3);
    expect(full.home).toBeCloseTo(0, 3);            // 100% renewable = near-zero electricity emissions
  });

  it('home emissions divided by household size', () => {
    const r1 = calculateFootprint({ ...base, elecKwh: 300, hhSize: 1 });
    const r3 = calculateFootprint({ ...base, elecKwh: 300, hhSize: 3 });
    expect(r3.home).toBeCloseTo(r1.home / 3, 3);
  });

  it('gas contributes independently of electricity', () => {
    const gasOnly  = calculateFootprint({ ...base, gasM3: 50, elecKwh: 0 });
    const elecOnly = calculateFootprint({ ...base, gasM3: 0,  elecKwh: 300 });
    expect(gasOnly.home).toBeGreaterThan(0);
    expect(elecOnly.home).toBeGreaterThan(0);
  });

  it('hhSize defaults to minimum 1 (no division by zero)', () => {
    expect(() => calculateFootprint({ ...base, hhSize: 0 })).not.toThrow();
    const r = calculateFootprint({ ...base, elecKwh: 300, hhSize: 0 });
    expect(isFinite(r.home)).toBe(true);
    expect(r.home).toBeGreaterThan(0);
  });
});

describe('calculateFootprint — food', () => {
  it('vegan diet has lower emissions than heavy-meat diet', () => {
    const vegan  = calculateFootprint({ ...base, dietType: 'vegan' });
    const heavy  = calculateFootprint({ ...base, dietType: 'heavy-meat' });
    expect(vegan.food).toBeLessThan(heavy.food);
  });

  it('diet progression is monotonically decreasing', () => {
    const diets = ['heavy-meat', 'meat', 'moderate', 'pescatarian', 'vegetarian', 'vegan'];
    const values = diets.map(d => calculateFootprint({ ...base, dietType: d }).food);
    for (let i = 1; i < values.length; i++) {
      expect(values[i]).toBeLessThanOrEqual(values[i - 1]);
    }
  });

  it('low food waste reduces emissions vs high food waste', () => {
    const hi = calculateFootprint({ ...base, foodWaste: 'high' });
    const lo = calculateFootprint({ ...base, foodWaste: 'low'  });
    expect(lo.food).toBeLessThan(hi.food);
  });

  it('local food reduces emissions vs non-local', () => {
    const far   = calculateFootprint({ ...base, localFood: 'low'  });
    const local = calculateFootprint({ ...base, localFood: 'high' });
    expect(local.food).toBeLessThan(far.food);
  });

  it('unknown diet type falls back to meat baseline', () => {
    const r = calculateFootprint({ ...base, dietType: 'unknown-type' });
    const meat = calculateFootprint({ ...base, dietType: 'meat' });
    expect(r.food).toBeCloseTo(meat.food, 3);
  });
});

describe('calculateFootprint — stuff', () => {
  it('returns zero stuff for all-zero stuff inputs', () => {
    const r = calculateFootprint(base);
    expect(r.stuff).toBe(0);
  });

  it('clothing items accumulate annually (monthly × 12)', () => {
    const r = calculateFootprint({ ...base, clothingItems: 1 });
    expect(r.stuff).toBeCloseTo(1 * 12 * 6.5 / 1000, 4);
  });

  it('electronics cost is per device per year', () => {
    const r = calculateFootprint({ ...base, electronics: 2 });
    expect(r.stuff).toBeCloseTo(2 * 150 / 1000, 4);
  });

  it('online orders accumulate weekly', () => {
    const r = calculateFootprint({ ...base, onlineOrders: 5 });
    expect(r.stuff).toBeCloseTo(5 * 52 * 2.2 / 1000, 4);
  });
});

describe('calculateFootprint — totals', () => {
  it('total equals sum of all categories', () => {
    const r = calculateFootprint({
      ...base,
      carKm: 150, longFlights: 1,
      elecKwh: 250, gasM3: 30,
      dietType: 'moderate',
      clothingItems: 2,
    });
    expect(r.total).toBeCloseTo(r.transport + r.home + r.food + r.stuff, 5);
  });

  it('all return values are finite numbers', () => {
    const r = calculateFootprint(base);
    ['transport', 'home', 'food', 'stuff', 'total'].forEach(k => {
      expect(typeof r[k]).toBe('number');
      expect(isFinite(r[k])).toBe(true);
    });
  });

  it('all return values are non-negative', () => {
    const r = calculateFootprint(base);
    ['transport', 'home', 'food', 'stuff', 'total'].forEach(k => {
      expect(r[k]).toBeGreaterThanOrEqual(0);
    });
  });
});

// ── getScoreLabel ──────────────────────────────────────────────────────────
describe('getScoreLabel', () => {
  it('≤ 2t → Climate Champion, cls good', () => {
    const l = getScoreLabel(1.5);
    expect(l.text).toContain('Climate Champion');
    expect(l.cls).toBe('good');
  });

  it('> 2t and ≤ 4t → Below Global Avg, cls good', () => {
    const l = getScoreLabel(3.0);
    expect(l.cls).toBe('good');
    expect(l.text).toContain('Below Global Avg');
  });

  it('> 4t and ≤ 8t → Room to Improve, cls warn', () => {
    const l = getScoreLabel(6.5);
    expect(l.cls).toBe('warn');
  });

  it('> 8t and ≤ 14t → High Footprint, cls bad', () => {
    const l = getScoreLabel(12);
    expect(l.cls).toBe('bad');
    expect(l.text).toContain('High Footprint');
  });

  it('> 14t → Very High, cls bad', () => {
    const l = getScoreLabel(20);
    expect(l.cls).toBe('bad');
    expect(l.text).toContain('Very High');
  });

  it('boundary: exactly 2t is Climate Champion', () => {
    expect(getScoreLabel(2).cls).toBe('good');
  });

  it('boundary: exactly 4t is still good', () => {
    expect(getScoreLabel(4).cls).toBe('good');
  });

  it('boundary: just above 4t is warn', () => {
    expect(getScoreLabel(4.1).cls).toBe('warn');
  });
});
