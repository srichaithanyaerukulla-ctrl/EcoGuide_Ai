/**
 * api.js
 * Handles all communication with the Anthropic Claude API.
 */

const API_URL   = 'https://api.anthropic.com/v1/messages';
const API_MODEL = 'claude-sonnet-4-6';

/**
 * Build a detailed, personalised prompt from user results + inputs.
 */
export function buildPrompt(results, inputs) {
  const {
    carKm, isEV, shortFlights, longFlights,
    elecKwh, renewShare,
    dietType, foodWaste,
    clothingItems,
  } = inputs;

  const renewPct = Math.round((renewShare || 0) * 100);

  return `You are EcoGuide AI, an encouraging and knowledgeable personal carbon footprint advisor.

A user has just calculated their annual carbon footprint using scientifically-validated emission factors.

USER'S FOOTPRINT DATA:
- Total annual footprint: ${results.total.toFixed(2)} tonnes CO₂e
- Transport: ${results.transport.toFixed(2)} t  (car km/wk: ${carKm || 0}, EV: ${isEV}, short flights/yr: ${shortFlights || 0}, long flights/yr: ${longFlights || 0})
- Home energy: ${results.home.toFixed(2)} t  (electricity: ${elecKwh || 0} kWh/mo, renewables: ${renewPct}%)
- Food & diet: ${results.food.toFixed(2)} t  (diet: ${dietType}, waste level: ${foodWaste})
- Shopping: ${results.stuff.toFixed(2)} t  (clothing items/mo: ${clothingItems || 0})

CONTEXT:
- Global average: 4.8 tonnes/year
- 2050 Paris-aligned target: 2 tonnes/year
- The user's biggest category is: ${getBiggest(results)}

Please write a personalised carbon footprint analysis with EXACTLY these five sections, using these exact headers:

### 🔍 Your Footprint at a Glance
Write 2–3 sentences giving an honest, encouraging summary. Say how they compare to the global average and 2050 target. Mention their biggest emission category by name and exact tonnage.

### 🎯 Your Top 3 Priority Actions
Choose the 3 highest-impact, most specific actions for THIS person based on their actual numbers. For each action:
- Name the action clearly (bold)
- Explain WHY it matters specifically for their numbers (reference their actual data)
- State the estimated CO₂e saving in kg/year
Format each as a short paragraph, not a bullet list.

### 💡 Quick Wins This Week
List exactly 3 things they can do in the next 7 days with minimal cost or effort. Keep each to one sentence. Use a bullet list.

### 🌱 12-Month Roadmap
Month-by-month plan to reduce their footprint by at least 30%. Pair months (e.g. "Months 1–2:"). Aim for 6 pairs covering a year. One sentence per pair.

### 📊 Collective Impact
One powerful, specific sentence: if 1 million people took their single highest-impact action, what would the total CO₂ saving be? Show the maths briefly (e.g. "1M × 2.8t = 2.8 billion kg").

Tone: warm, specific, data-driven. Not preachy. Reference their actual numbers throughout. Use **bold** for key figures.`;
}

function getBiggest(results) {
  const cats = { Transport: results.transport, Home: results.home, Food: results.food, Stuff: results.stuff };
  return Object.entries(cats).sort((a, b) => b[1] - a[1])[0][0];
}

/**
 * Call Claude API and return raw text.
 * Throws on network/API error.
 */
export async function callClaude(prompt) {
  const response = await fetch(API_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:      API_MODEL,
      max_tokens: 1000,
      messages:   [{ role: 'user', content: prompt }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }

  const data = await response.json();
  return data.content
    .filter((b) => b.type === 'text')
    .map((b) => b.text)
    .join('\n');
}

/**
 * Fallback insights when API is unavailable.
 * Generates personalised text from user data without calling the API.
 */
export function buildFallbackInsights(results, inputs) {
  const biggest = getBiggest(results);
  const biggestVal = results[biggest.toLowerCase()];
  const saving20pct = (biggestVal * 0.2 * 1000).toFixed(0);
  const homeSaving  = (results.home * 0.7 * 1000).toFixed(0);
  const isAbove     = results.total > 4.8;
  const diffPct     = Math.abs(((results.total / 4.8) - 1) * 100).toFixed(0);

  return `### 🔍 Your Footprint at a Glance

Your annual footprint is **${results.total.toFixed(1)} tonnes CO₂e** — ${isAbove
    ? `**${diffPct}% above** the global average of 4.8t`
    : `**${diffPct}% below** the global average of 4.8t — well done!`
}. Your biggest source is **${biggest}** at **${biggestVal.toFixed(1)} tonnes**, which is the most powerful place to focus first. ${results.total > 2
    ? 'You\'re above the 2050 climate target of 2t, but with a few focused changes, you can get there.'
    : 'You\'re already at or near the 2050 climate target of 2t — impressive!'}

### 🎯 Your Top 3 Priority Actions

**1. Reduce ${biggest} emissions.** Since this is your largest category at ${biggestVal.toFixed(1)}t, even a 20% reduction here would save approximately **${saving20pct} kg CO₂e per year** — equivalent to planting over ${Math.round(parseInt(saving20pct) / 20)} trees.

**2. Switch to green electricity.** ${inputs.renewShare < 1
    ? `You're currently at ${Math.round((inputs.renewShare || 0) * 100)}% renewables. Switching to 100% renewable power could cut your home energy emissions by up to 90%, saving roughly **${homeSaving} kg CO₂e/year**.`
    : 'You\'re already on 100% renewables — fantastic. Focus on reducing your total consumption next.'}

**3. Reduce meat consumption by two meals per week.** Swapping beef for plant-based meals twice per week typically saves **400–600 kg CO₂e annually** with minimal lifestyle change and health benefits to boot.

### 💡 Quick Wins This Week

- Turn your thermostat down 1°C — this alone saves ~8% on heating energy
- Plan your weekly meals before shopping to avoid food waste
- Walk or cycle for any trip under 3 km instead of driving

### 🌱 12-Month Roadmap

**Months 1–2:** Audit your home energy use and switch to a green electricity tariff if not already done. **Months 3–4:** Remove meat from two dinners per week and try one fully plant-based day. **Months 5–6:** Shift one commute day per week to public transit or cycling. **Months 7–8:** Declutter and commit to buying only second-hand clothing for six months. **Months 9–10:** Plan your next holiday without flying if possible — consider train travel. **Months 11–12:** Review your footprint again — following this roadmap, you should be 25–35% lower than when you started.

### 📊 Collective Impact

If 1 million people each cut one long-haul flight per year, that eliminates **1M × 1.62t = 1.62 billion kg CO₂** — equivalent to taking over 350,000 cars off the road for an entire year.`;
}
