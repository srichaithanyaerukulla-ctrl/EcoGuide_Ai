/**
 * ui.js
 * All DOM manipulation, rendering, and UI helpers.
 * Keeps main.js thin — this is the "view" layer.
 */

/* ── Helpers ─────────────────────────────── */
export const $ = (sel) => document.querySelector(sel);
export const $$ = (sel) => document.querySelectorAll(sel);
export const show = (el) => el?.classList.remove('hidden');
export const hide = (el) => el?.classList.add('hidden');

/** Smooth-scroll to any CSS selector */
export function goto(sel) {
  $(sel)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ── Hero counter animation ─────────────── */
export function animateCounter(targetEl, target, duration = 2200) {
  const start = performance.now();
  function step(now) {
    const p    = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    targetEl.textContent = (ease * target).toFixed(1);
    if (p < 1) requestAnimationFrame(step);
    else targetEl.textContent = target;
  }
  requestAnimationFrame(step);
}

/* ── Nav ─────────────────────────────────── */
export function initNav() {
  const nav    = $('#nav');
  const burger = $('#navBurger');
  const mobile = $('#navMobile');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
  });

  burger?.addEventListener('click', () => {
    const open = burger.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
    mobile.classList.toggle('hidden', !open);
    // Close on link click
    $$('.nav__mob-link').forEach((a) => {
      a.addEventListener('click', () => {
        burger.classList.remove('open');
        burger.setAttribute('aria-expanded', false);
        mobile.classList.add('hidden');
      });
    });
  });

  // Active link highlight on scroll
  const sections = $$('section[id]');
  const links    = $$('.nav__link');
  const obs = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          links.forEach((l) => l.classList.remove('active'));
          $$(`a[href="#${e.target.id}"]`).forEach((l) => l.classList.add('active'));
        }
      });
    },
    { rootMargin: '-40% 0px -55% 0px' }
  );
  sections.forEach((s) => obs.observe(s));
}

/* ── Form tabs ───────────────────────────── */
export function initTabs() {
  $$('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      $$('.tab').forEach((b)   => { b.classList.remove('on'); b.setAttribute('aria-selected', 'false'); });
      $$('.panel').forEach((p) => { p.classList.remove('on'); p.setAttribute('hidden', ''); });
      btn.classList.add('on');
      btn.setAttribute('aria-selected', 'true');
      const panel = $(`#tab-${btn.dataset.tab}`);
      panel.classList.add('on');
      panel.removeAttribute('hidden');
    });
  });
}

/* ── Result panel ────────────────────────── */
export function renderResult(results) {
  const { transport, home, food, stuff, total } = results;

  hide($('#resultPh'));
  show($('#resultData'));

  // Score number
  $('#totalNum').textContent = total.toFixed(1);

  // Score label
  const lb = getScoreLabel(total);
  const sl = $('#scoreLabel');
  sl.textContent = lb.text;
  sl.className   = 'score-label'; // reset

  // Donut ring
  const CIRC   = 314; // 2πr, r=50
  const pct    = Math.min(total / 20, 1);
  const colors = { good: '#4A8C5C', warn: '#D4873A', bad: '#C05B5B' };
  const arc    = $('#donutArc');
  arc.style.strokeDashoffset = CIRC - pct * CIRC;
  arc.style.stroke           = colors[lb.cls];

  // Breakdown bars
  const max = Math.max(transport, home, food, stuff, 0.001);
  [
    ['T', transport],
    ['H', home],
    ['F', food],
    ['S', stuff],
  ].forEach(([key, val]) => {
    $(`#b${key}`).style.width     = `${(val / max) * 100}%`;
    $(`#v${key}`).textContent     = `${val.toFixed(1)}t`;
  });

  // Benchmark badges
  setBadge('#badgeGlobal', total, 4.8);
  setBadge('#badgeTarget', total, 2.0);

  // Scroll result into view
  setTimeout(
    () => $('#resultPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' }),
    150
  );
}

function getScoreLabel(total) {
  if (total <= 2)  return { text: 'Climate Champion 🌱', cls: 'good' };
  if (total <= 4)  return { text: 'Below Global Avg ✅',  cls: 'good' };
  if (total <= 8)  return { text: 'Room to Improve ⚠️',  cls: 'warn' };
  if (total <= 14) return { text: 'High Footprint 🔴',   cls: 'bad' };
  return                   { text: 'Very High 🚨',        cls: 'bad' };
}

function setBadge(selector, val, benchmark) {
  const el = $(selector);
  if (!el) return;
  if (val < benchmark) {
    el.textContent = `${((1 - val / benchmark) * 100).toFixed(0)}% below`;
    el.className   = 'cmp-badge good';
  } else {
    el.textContent = `${((val / benchmark - 1) * 100).toFixed(0)}% above`;
    el.className   = `cmp-badge ${val > benchmark * 1.5 ? 'bad' : 'warn'}`;
  }
}

/* ── Insights panel ──────────────────────── */
export function showInsightsLoading() {
  hide($('#insEmpty'));
  hide($('#insContent'));
  const ld = $('#insLoading');
  ld.classList.remove('hidden');
  ld.style.display = 'flex';
  goto('#insights');
}

export function renderInsights(rawText) {
  hide($('#insLoading'));
  hide($('#insEmpty'));
  const content = $('#insContent');
  show(content);
  content.classList.remove('hidden');

  // Markdown-lite → HTML (sanitized: only known-safe tags produced)
  const sanitizeText = (str) =>
    str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

  const html = rawText
    .split(/\n/)
    .map((line) => {
      // Headings
      const h3 = line.match(/^###\s+(.*)/);
      if (h3) return `<h3>${sanitizeText(h3[1])}</h3>`;
      const h2 = line.match(/^##\s+(.*)/);
      if (h2) return `<h3>${sanitizeText(h2[1])}</h3>`;
      // List items
      const li = line.match(/^[-*]\s+(.*)/);
      if (li) return `<li>${applyInline(li[1])}</li>`;
      // Blank lines → paragraph break marker
      if (line.trim() === '') return '__BREAK__';
      return applyInline(line);
    })
    .join('\n')
    .replace(/((<li>.*<\/li>\n?)+)/g, '<ul>$1</ul>')
    .split('__BREAK__')
    .map((block) => block.trim())
    .filter(Boolean)
    .map((block) => (block.startsWith('<') ? block : `<p>${block}</p>`))
    .join('');

  $('#insBody').innerHTML           = html;
  $('#insTime').textContent         = `Generated ${new Date().toLocaleTimeString()}`;
}

export function showInsightsError() {
  hide($('#insLoading'));
  show($('#insEmpty'));
  $('#insEmpty').querySelector('p').textContent =
    '⚠️ Could not connect to AI. Check your internet connection and try again.';
}

/** Apply inline bold formatting safely */
function applyInline(text) {
  // Only allow **bold** — sanitize first, then re-apply bold tags
  const safe = text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return safe.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
}

/* ── Actions grid ────────────────────────── */
export function renderActions(actions, committed, onToggle) {
  const grid = $('#actGrid');
  if (!grid) return;
  grid.innerHTML = '';

  actions.forEach((action) => {
    const done = committed.has(action.id);
    const dots = Array.from({ length: 5 }, (_, i) =>
      `<span class="${i < action.lvl ? 'on' : ''}"></span>`
    ).join('');

    const card = document.createElement('article');
    card.className       = `act-card${done ? ' done' : ''}`;
    card.dataset.id      = action.id;
    card.setAttribute('role', 'listitem');
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-pressed', done);
    card.setAttribute('aria-label', `${action.title} — saves ${action.impact} kg CO₂e per year`);

    card.innerHTML = `
      <div class="act-chk" aria-hidden="true">${done ? '✓' : ''}</div>
      <div class="act-body">
        <div class="act-title">${action.title}</div>
        <div class="act-desc">${action.desc}</div>
        <div class="act-meta">
          <span class="act-impact">−${action.impact.toLocaleString()} kg/yr</span>
          <span class="act-cat">${getCatIcon(action.cat)}</span>
          <div class="act-dots" aria-label="Impact level ${action.lvl} of 5">${dots}</div>
        </div>
      </div>`;

    card.addEventListener('click',  () => onToggle(action.id, card));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onToggle(action.id, card); }
    });

    // Entrance animation
    card.style.opacity   = '0';
    card.style.transform = 'translateY(14px)';

    grid.appendChild(card);
  });

  // Staggered reveal
  grid.querySelectorAll('.act-card').forEach((el, i) => {
    setTimeout(() => {
      el.style.transition = `opacity .4s ease, transform .4s ease`;
      el.style.opacity    = '1';
      el.style.transform  = 'translateY(0)';
    }, i * 45);
  });

  $('#totalCount').textContent = countAll();
}

function countAll() {
  // Keep showing total regardless of filter
  return document.getElementById('totalCount')?.dataset.total ?? '0';
}

function getCatIcon(cat) {
  return { transport: '🚗', home: '🏠', food: '🍽️', stuff: '🛍️' }[cat] ?? '';
}

/** Update committed card DOM after toggle */
export function updateCardDOM(card, isDone) {
  card.classList.toggle('done', isDone);
  card.querySelector('.act-chk').textContent = isDone ? '✓' : '';
  card.setAttribute('aria-pressed', isDone);
}

/** Update progress bar and counters */
export function updateProgress(committed, allActions) {
  const count = committed.size;
  const total = allActions.length;
  const saved = allActions
    .filter((a) => committed.has(a.id))
    .reduce((s, a) => s + a.impact, 0);

  $('#doneCount').textContent = count;
  $('#progFill').style.width  = `${(count / total) * 100}%`;
  $('#savedCO2').textContent  = `${saved.toLocaleString()} kg`;

  const bar = $('#progBar');
  if (bar) bar.setAttribute('aria-valuenow', Math.round((count / total) * 100));
}

/* ── Scroll reveal ───────────────────────── */
export function initScrollReveal() {
  const obs = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('vis');
          obs.unobserve(e.target);
        }
      });
    },
    { threshold: 0.12 }
  );
  $$('.reveal').forEach((el) => obs.observe(el));
}

// Expose goto globally so inline onclick attrs work
window.UI = { goto };