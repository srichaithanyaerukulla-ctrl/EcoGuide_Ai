/**
 * Emission Factors — kg CO₂e per unit
 * Sources: IPCC AR6, Our World in Data, EPA 2023
 */
export const EF = {
  // Transport
  carPetrol:    0.21,    // per km (avg petrol/diesel car)
  carEV:        0.053,   // per km (global grid mix)
  transit:      0.089,   // per hour (bus/rail mix)
  shortFlight:  255,     // per return trip, economy (< 3h)
  longFlight:   1620,    // per return trip, economy (> 3h)

  // Home
  electricity:  0.233,   // per kWh (global avg grid)
  gas:          2.04,    // per m³ natural gas

  // Food (kg CO₂e per year)
  diet: {
    'heavy-meat':  3300,
    'meat':        2500,
    'moderate':    1900,
    'pescatarian': 1500,
    'vegetarian':  1200,
    'vegan':        900,
  },

  // Food modifiers (multipliers)
  foodWaste: { high: 1.2, medium: 1.0, low: 0.85 },
  localFood:  { low:  1.1, medium: 1.0, high: 0.9 },

  // Stuff
  clothing:    6.5,   // per garment (avg lifecycle)
  electronics: 150,   // per device (avg)
  onlineOrder: 2.2,   // per delivery (last-mile)
};

/** Global benchmarks in tonnes CO₂e */
export const BENCHMARKS = {
  global:  4.8,
  usa:     16.0,
  target:  2.0,   // Paris-aligned 2050 target
  uk:      5.5,
  india:   1.9,
};
