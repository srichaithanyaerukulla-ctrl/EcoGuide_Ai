/**
 * Climate Actions Library
 * impact: estimated annual CO₂e saving in kg
 * lvl:    impact level 1–5 (5 = highest)
 */
export const ACTIONS = [
  // ── Transport ─────────────────────────────────────
  {
    id: 't1', cat: 'transport', impact: 1200, lvl: 3,
    title: 'Go car-free one day per week',
    desc:  'Walk, cycle, or take transit for all trips one day each week.',
  },
  {
    id: 't2', cat: 'transport', impact: 2800, lvl: 5,
    title: 'Cut one long-haul flight per year',
    desc:  'Replace with train travel or video calls where possible.',
  },
  {
    id: 't3', cat: 'transport', impact: 950, lvl: 3,
    title: 'Switch to public transit for commuting',
    desc:  'Bus or rail instead of a personal car for your daily commute.',
  },
  {
    id: 't4', cat: 'transport', impact: 350, lvl: 2,
    title: 'Carpool twice a week',
    desc:  'Sharing a ride with one other person halves per-person emissions.',
  },
  {
    id: 't5', cat: 'transport', impact: 1500, lvl: 4,
    title: 'Switch to an EV or hybrid',
    desc:  'Electric vehicles on average grids emit 60–70% less than petrol cars.',
  },
  {
    id: 't6', cat: 'transport', impact: 280, lvl: 2,
    title: 'Cycle for trips under 5 km',
    desc:  'A bike replaces the highest-emission transport mode: short car trips.',
  },

  // ── Home ──────────────────────────────────────────
  {
    id: 'h1', cat: 'home', impact: 800, lvl: 3,
    title: 'Switch to a green energy tariff',
    desc:  'Choose a supplier sourcing 100% renewable electricity.',
  },
  {
    id: 'h2', cat: 'home', impact: 450, lvl: 1,
    title: 'Turn heating down 1°C',
    desc:  'Each degree less reduces heating energy use by approximately 8%.',
  },
  {
    id: 'h3', cat: 'home', impact: 600, lvl: 3,
    title: 'Improve home insulation',
    desc:  'Loft and wall insulation can cut heating bills and emissions by 20–30%.',
  },
  {
    id: 'h4', cat: 'home', impact: 350, lvl: 1,
    title: 'Switch to LED lighting throughout',
    desc:  'LEDs use ~75% less energy than incandescent bulbs and last 25× longer.',
  },
  {
    id: 'h5', cat: 'home', impact: 280, lvl: 1,
    title: 'Unplug devices on standby',
    desc:  'Standby power accounts for up to 10% of a typical home\'s electricity use.',
  },
  {
    id: 'h6', cat: 'home', impact: 400, lvl: 2,
    title: 'Install a smart thermostat',
    desc:  'Smart thermostats reduce heating and cooling energy use by an average of 12%.',
  },

  // ── Food ──────────────────────────────────────────
  {
    id: 'f1', cat: 'food', impact: 1100, lvl: 3,
    title: 'Go meat-free two days per week',
    desc:  'Plant-based meals have on average 10× less carbon than beef meals.',
  },
  {
    id: 'f2', cat: 'food', impact: 650, lvl: 3,
    title: 'Reduce beef & dairy by half',
    desc:  'Beef and dairy together account for ~14.5% of global GHG emissions.',
  },
  {
    id: 'f3', cat: 'food', impact: 300, lvl: 2,
    title: 'Cut household food waste in half',
    desc:  'About one-third of all food produced globally is wasted — costing carbon and money.',
  },
  {
    id: 'f4', cat: 'food', impact: 180, lvl: 1,
    title: 'Buy local and seasonal produce',
    desc:  'Local food typically travels less and is grown more in-season.',
  },
  {
    id: 'f5', cat: 'food', impact: 90, lvl: 1,
    title: 'Start a home herb or vegetable garden',
    desc:  'Even a small pot of tomatoes offsets packaging and transport emissions.',
  },

  // ── Stuff ─────────────────────────────────────────
  {
    id: 's1', cat: 'stuff', impact: 450, lvl: 2,
    title: 'Buy half as many new clothes',
    desc:  'Fashion = ~10% of global CO₂. Wearing items longer is the most effective lever.',
  },
  {
    id: 's2', cat: 'stuff', impact: 380, lvl: 2,
    title: 'Buy second-hand or swap clothing',
    desc:  'Extends garment life and avoids virgin production entirely.',
  },
  {
    id: 's3', cat: 'stuff', impact: 300, lvl: 2,
    title: 'Repair electronics instead of replacing',
    desc:  'A smartphone alone emits ~70 kg CO₂e to produce. Repair extends life by years.',
  },
  {
    id: 's4', cat: 'stuff', impact: 150, lvl: 1,
    title: 'Bundle online orders to fewer deliveries',
    desc:  'Last-mile delivery is disproportionately emission-heavy. Fewer trips matter.',
  },
  {
    id: 's5', cat: 'stuff', impact: 200, lvl: 1,
    title: 'Avoid single-use plastics',
    desc:  'Reusable bags, bottles, and cups save both production and waste emissions.',
  },
];

export const CAT_ICON = {
  transport: '🚗',
  home:      '🏠',
  food:      '🍽️',
  stuff:     '🛍️',
};
