/**
 * main.js — EcoGuide AI
 * Entry point. Imports modules and wires up all event listeners.
 */

import '../styles/main.css';
import '../styles/nav.css';
import '../styles/hero.css';
import '../styles/components.css';

import { calculateFootprint, readFormInputs } from './calculator.js';
import { buildPrompt, callClaude, buildFallbackInsights } from './api.js';
import { ACTIONS }  from './data/actions.js';
import {
  $, $$,
  animateCounter,
  initNav,
  initTabs,
  renderResult,
  showInsightsLoading,
  renderInsights,
  showInsightsError,
  renderActions,
  updateCardDOM,
  updateProgress,
  initScrollReveal,
} from './ui.js';

/* ════════════════════════════════════════════
   APP STATE
════════════════════════════════════════════ */
const state = {
  results:   null,
  inputs:    null,
  committed: new Set(),
  filter:    'all',
};

/* ════════════════════════════════════════════
   INIT
════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  // Hero counter
  animateCounter($('#heroNum'), 4.8);

  // Nav + tabs
  initNav();
  initTabs();

  // Actions
  renderActionsView();
  $('#actGrid').dataset.total = ACTIONS.length;
  $('#totalCount').textContent = ACTIONS.length;

  // Scroll reveal
  initScrollReveal();

  // Button listeners
  $('#calcBtn')?.addEventListener('click', handleCalculate);
  $('#insightBtn')?.addEventListener('click', handleInsights);
  $('#regenBtn')?.addEventListener('click', handleInsights);

  // Filter buttons
  $$('.act-filter').forEach((btn) => {
    btn.addEventListener('click', () => {
      $$('.act-filter').forEach((b) => b.classList.remove('on'));
      btn.classList.add('on');
      state.filter = btn.dataset.f;
      renderActionsView();
    });
  });
});

/* ════════════════════════════════════════════
   CALCULATE
════════════════════════════════════════════ */
function handleCalculate() {
  const inputs  = readFormInputs();
  const results = calculateFootprint(inputs);

  state.inputs  = inputs;
  state.results = results;

  renderResult(results);
}

/* ════════════════════════════════════════════
   AI INSIGHTS
════════════════════════════════════════════ */
async function handleInsights() {
  if (!state.results) {
    alert('Please calculate your footprint first using the form above.');
    return;
  }

  showInsightsLoading();

  try {
    const prompt = buildPrompt(state.results, state.inputs);
    const text   = await callClaude(prompt);
    renderInsights(text);
  } catch (err) {
    console.warn('Claude API unavailable, using fallback:', err.message);
    // Graceful fallback — still shows personalised content
    const fallback = buildFallbackInsights(state.results, state.inputs);
    renderInsights(fallback);
  }
}

/* ════════════════════════════════════════════
   ACTIONS
════════════════════════════════════════════ */
function renderActionsView() {
  const list = state.filter === 'all'
    ? ACTIONS
    : ACTIONS.filter((a) => a.cat === state.filter);

  renderActions(list, state.committed, handleToggleAction);
  updateProgress(state.committed, ACTIONS);
}

function handleToggleAction(id, card) {
  const isDone = state.committed.has(id);
  if (isDone) {
    state.committed.delete(id);
  } else {
    state.committed.add(id);
  }
  updateCardDOM(card, !isDone);
  updateProgress(state.committed, ACTIONS);
}
