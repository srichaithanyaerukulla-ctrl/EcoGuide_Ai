/**
 * calculator.js
 * Pure functions — no DOM access, fully testable.
 */
import { EF } from './data/emissionFactors.js';

/**
 * Read form values and compute annual CO₂e in tonnes.
 * @param {Object} inputs  – key/value map of form field values
 * @returns {{ transport, home, food, stuff, total }}  in tonnes CO₂e / year
 */
export function calculateFootprint(inputs) {
  const {
    carKm        = 0,
    isEV         = false,
    transitHrs   = 0,
    shortFlights  = 0,
    longFlights   = 0,
    elecKwh      = 0,
    gasM3        = 0,
    renewShare   = 0,
    hhSize       = 1,
    dietType     = 'meat',
    foodWaste    = 'medium',
    localFood    = 'medium',
    clothingItems = 0,
    electronics  = 0,
    onlineOrders = 0,
  } = inputs;

  // Transport (kg)
  const transport =
    (carKm * 52 * (isEV ? EF.carEV : EF.carPetrol)) +
    (transitHrs * 52 * EF.transit) +
    (shortFlights * EF.shortFlight) +
    (longFlights  * EF.longFlight);

  // Home (kg) — split by household
  const hh = Math.max(1, hhSize);
  const home = (
    (elecKwh * 12 * EF.electricity * (1 - renewShare)) +
    (gasM3   * 12 * EF.gas)
  ) / hh;

  // Food (kg)
  const baseDiet = EF.diet[dietType] ?? EF.diet['meat'];
  const food = baseDiet
    * (EF.foodWaste[foodWaste] ?? 1)
    * (EF.localFood[localFood] ?? 1);

  // Stuff (kg)
  const stuff =
    (clothingItems * 12 * EF.clothing) +
    (electronics   * EF.electronics) +
    (onlineOrders  * 52 * EF.onlineOrder);

  // Convert to tonnes
  const t = (v) => v / 1000;
  return {
    transport: t(transport),
    home:      t(home),
    food:      t(food),
    stuff:     t(stuff),
    total:     t(transport + home + food + stuff),
  };
}

/**
 * Get a score label + CSS class for a total tonnage.
 */
export function getScoreLabel(total) {
  if (total <= 2)  return { text: 'Climate Champion 🌱', cls: 'good' };
  if (total <= 4)  return { text: 'Below Global Avg ✅', cls: 'good' };
  if (total <= 8)  return { text: 'Room to Improve ⚠️',  cls: 'warn' };
  if (total <= 14) return { text: 'High Footprint 🔴',   cls: 'bad' };
  return                   { text: 'Very High 🚨',        cls: 'bad' };
}

/**
 * Read all form inputs into a plain object.
 */
export function readFormInputs() {
  const n = (id) => parseFloat(document.getElementById(id)?.value) || 0;
  const s = (id) => document.getElementById(id)?.value ?? '';

  return {
    carKm:         n('carKm'),
    isEV:          document.getElementById('isEV')?.checked ?? false,
    transitHrs:    n('transitHrs'),
    shortFlights:  n('shortFlights'),
    longFlights:   n('longFlights'),
    elecKwh:       n('elecKwh'),
    gasM3:         n('gasM3'),
    renewShare:    parseFloat(s('renewShare')) || 0,
    hhSize:        n('hhSize') || 1,
    dietType:      s('dietType') || 'meat',
    foodWaste:     s('foodWaste') || 'medium',
    localFood:     s('localFood') || 'medium',
    clothingItems: n('clothingItems'),
    electronics:   n('electronics'),
    onlineOrders:  n('onlineOrders'),
  };
}
