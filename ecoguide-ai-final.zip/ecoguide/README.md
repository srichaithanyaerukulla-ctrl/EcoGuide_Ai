# 🌿 EcoGuide AI

> Understand, track, and reduce your carbon footprint through simple actions and personalised AI insights.

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/YOUR_USERNAME/ecoguide-ai)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/YOUR_USERNAME/ecoguide-ai)

---

## 🎯 Chosen Vertical

**Carbon Footprint & Sustainability** — a smart assistant that helps individuals understand, track, and reduce their personal CO₂ emissions through data-driven insights and an integrated AI advisor.

The persona is an everyday person who is climate-aware but overwhelmed by complexity — they need clarity, not guilt. EcoGuide AI gives them a number, explains it, and shows exactly what to do next.

---

## 🧠 Approach & Logic

The solution is built around a three-phase user journey that mirrors how behaviour change actually works:

1. **Understand** — Before tracking, users need context. The Understand section teaches the four emission categories (Transport 29%, Food 26%, Stuff 24%, Home 21%) with real IPCC data, building the mental model needed to act.

2. **Track** — A 15-input calculator across 4 tabs (Transport, Home, Food, Stuff) uses peer-reviewed emission factors to compute an annual CO₂e figure. The calculator is a pure function (`calculateFootprint`) with no DOM dependencies — making it testable and accurate.

3. **Reduce** — Two reduction mechanisms work together:
   - **AI Insights**: Claude Sonnet 4.6 is called with the user's actual numbers and generates a personalised 5-section analysis (Glance, Top 3 Actions, Quick Wins, 12-Month Roadmap, Collective Impact). The prompt is dynamically rebuilt from real inputs — not a template.
   - **Actions Library**: 21 curated climate actions with CO₂ savings, category filters, commit tracking, and a running total of committed savings.

**Decision-making logic** flows through the app contextually:
- Donut ring colour changes green/amber/red based on score thresholds
- Benchmark badges compare result against global average (4.8t) and 2050 target (2t)
- AI prompt references the user's actual biggest category, flight count, renewable percentage, etc.
- Graceful fallback: if the AI API is unavailable, personalised insights are still generated locally from the user's data

---

## ⚙️ How It Works

```
User fills form (15 inputs across 4 tabs)
        ↓
readFormInputs()          → plain JS object
        ↓
calculateFootprint()      → { transport, home, food, stuff, total } in tonnes CO₂e
        ↓
renderResult()            → donut chart, breakdown bars, benchmark badges
        ↓
[user clicks "Get Insights"]
        ↓
buildPrompt(results, inputs)  → context-rich prompt string
        ↓
callClaude(prompt)        → Claude Sonnet 4.6 via /v1/messages
        ↓  (on error)
buildFallbackInsights()   → personalised text without API
        ↓
renderInsights(text)      → sanitized HTML in insights panel
```

**Module architecture:**
- `calculator.js` — pure functions, zero DOM, fully unit-tested
- `api.js` — Claude API call + offline fallback
- `ui.js` — all DOM rendering, zero business logic
- `main.js` — thin orchestration layer wiring the above together
- `data/emissionFactors.js` — all constants with source citations
- `data/actions.js` — 21 actions with impact, category, description

---

## 📝 Assumptions Made

| Area | Assumption |
|---|---|
| Car emissions | Return trips; global average grid mix for EVs (0.053 kg/km) |
| Flights | Economy class; return trip; radiative forcing not included |
| Electricity | World average grid (0.233 kg/kWh); reduced proportionally by renewable share |
| Household energy | Total home energy divided equally among household members |
| Food | Annual emission averages per diet type (Oxford/Poore & Nemecek 2018); local food modifier is ±10% |
| Clothing | Average lifecycle emissions per garment (fast fashion estimate) |
| Online orders | Last-mile delivery only; warehouse/packaging not included |
| AI insights | Claude API available via platform proxy; fallback activates on any fetch error |

---

## ✅ Problem Statement Alignment

| Requirement | Implementation |
|---|---|
| **Understand** carbon footprint | `#understand` section — 4 source cards with real emission % data (Transport 29%, Home 21%, Food 26%, Stuff 24%) |
| **Track** activities | 4-tab calculator with 15 inputs and IPCC/EPA-sourced emission factors |
| **Reduce** through simple actions | 21 curated actions with CO₂ impact, category filters, commit tracking |
| **Personalised insights** | Claude AI (Sonnet 4.6) generates a custom 5-section analysis from user's actual numbers |

---

## 📁 Project Structure

```
ecoguide/
├── src/
│   ├── index.html              ← HTML entry point (Vite processes this)
│   ├── styles/
│   │   ├── main.css            ← Design tokens, reset, utilities
│   │   ├── nav.css             ← Navigation styles
│   │   ├── hero.css            ← Hero section + earth animation
│   │   └── components.css      ← All other components
│   └── js/
│       ├── main.js             ← App entry, event wiring
│       ├── calculator.js       ← Pure carbon calculation engine
│       ├── api.js              ← Claude AI integration + fallback
│       ├── ui.js               ← All DOM rendering helpers
│       └── data/
│           ├── emissionFactors.js  ← IPCC/EPA emission factors
│           └── actions.js          ← 21 climate actions library
├── public/
│   ├── favicon.svg
│   ├── robots.txt
│   └── manifest.webmanifest   ← PWA manifest
├── .github/
│   └── workflows/
│       └── deploy.yml          ← CI/CD: auto-deploy to Netlify on push
├── vite.config.js              ← Build configuration
├── netlify.toml                ← Netlify hosting config + headers
├── vercel.json                 ← Vercel hosting config (alternative)
├── .eslintrc.json
├── .prettierrc
├── .gitignore
└── package.json
```

---

## 🚀 Getting Started

### Prerequisites
- **Node.js** >= 18 ([download](https://nodejs.org))
- **npm** >= 9 (comes with Node)
- A **Git** client

### 1. Clone the repo

```bash
git clone https://github.com/YOUR_USERNAME/ecoguide-ai.git
cd ecoguide-ai
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Hot-reload is enabled — save any file and the browser updates instantly.

### 4. Build for production

```bash
npm run build
```

Output goes to `dist/`. Preview the production build locally:

```bash
npm run preview
```

---

## 🌐 Deployment

### Option A — Netlify (Recommended)

**One-click deploy:**

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/YOUR_USERNAME/ecoguide-ai)

**Manual CLI deploy:**

```bash
# Install Netlify CLI globally
npm install -g netlify-cli

# Login
netlify login

# Create a new site and deploy
netlify init
npm run deploy
```

**Auto-deploy via GitHub Actions:**

1. Push your code to GitHub
2. In Netlify: Site Settings → Build & Deploy → Continuous deployment → Link to GitHub repo
3. Add these secrets to your GitHub repo (Settings → Secrets):
   - `NETLIFY_AUTH_TOKEN` — from Netlify User Settings → Applications
   - `NETLIFY_SITE_ID` — from Netlify Site Settings → General → Site ID
4. Every push to `main` now auto-deploys. PRs get preview URLs.

### Option B — Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Production deploy
vercel --prod
```

Or use the Vercel dashboard: import your GitHub repo and it auto-detects the settings from `vercel.json`.

### Option C — GitHub Pages

```bash
npm run build
# Copy dist/ contents to gh-pages branch, or use gh-pages package:
npm install --save-dev gh-pages
npx gh-pages -d dist
```

Add to `vite.config.js`:
```js
base: '/ecoguide-ai/',  // your repo name
```

### Option D — Any static host (S3, Cloudflare Pages, Firebase Hosting)

Run `npm run build` and upload the `dist/` folder. All platforms work since EcoGuide AI is a pure static site.

---

## 🤖 Claude AI Integration

EcoGuide AI uses the **Anthropic Claude Sonnet 4.6** model to generate personalised insights.

The API is called from the browser via `https://api.anthropic.com/v1/messages`. In production on Netlify/Vercel, the API key is injected by the platform proxy (no key needed in code). For local development on your own server, the app gracefully falls back to pre-written personalised insights if the API is unavailable.

### Prompt architecture

```
buildPrompt(results, inputs)
  ↓
callClaude(prompt)           ← /v1/messages
  ↓ (on error)
buildFallbackInsights()      ← still personalised, no API needed
```

---

## 🔬 Emission Factors

All calculations use peer-reviewed sources:

| Factor | Value | Source |
|---|---|---|
| Petrol car | 0.21 kg CO₂e/km | EPA 2023 |
| Electric vehicle | 0.053 kg CO₂e/km | IPCC AR6 |
| Short-haul flight | 255 kg CO₂e/return | ICAO 2023 |
| Long-haul flight | 1,620 kg CO₂e/return | ICAO 2023 |
| Electricity (global) | 0.233 kg CO₂e/kWh | IEA 2023 |
| Natural gas | 2.04 kg CO₂e/m³ | IPCC AR6 |
| Vegan diet | 900 kg CO₂e/yr | Oxford (Poore & Nemecek 2018) |
| Heavy meat diet | 3,300 kg CO₂e/yr | Oxford (Poore & Nemecek 2018) |

---

## 🧪 Code Quality

```bash
# Lint
npm run lint

# Format
npm run format
```

ESLint config: `eslint:recommended` + `prefer-const`, `no-var`, `eqeqeq`.  
Prettier: single quotes, semicolons, 100-char print width.

---

## ♿ Accessibility

- Semantic HTML5 landmarks (`<nav>`, `<section>`, `<footer>`, `<article>`)
- ARIA roles, labels, and `aria-live` regions for dynamic content
- Keyboard navigation for all interactive elements (cards respond to Enter/Space)
- `prefers-reduced-motion` media query respected
- Visible `:focus-visible` outlines
- Colour contrast meets WCAG AA

---

## 📱 Browser Support

| Browser | Support |
|---|---|
| Chrome/Edge 90+ | ✅ Full |
| Firefox 88+ | ✅ Full |
| Safari 14+ | ✅ Full |
| Mobile (iOS/Android) | ✅ Responsive |

---

## 📄 License

MIT — free to use, modify, and deploy.

---

## 🙏 Credits

- Emission factors: **IPCC AR6**, **Our World in Data**, **EPA**, **Oxford University**
- AI insights: **Anthropic Claude**
- Fonts: **DM Serif Display**, **Inter**, **JetBrains Mono** (Google Fonts)
- Built with **Vite**
